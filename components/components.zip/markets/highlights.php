<div class="strip margin-mobi">
    <div class="icon">
        <span class="glyphicon glyphicon-globe" style="color:white;"></span>
    </div>
    <div class="heading">
        <span style="color:white; font-weight:bold;">HIGHLIGHTS</span>
    </div>
    <div class="icons">

    </div>
</div>

<div class="odds">
    <div class="heading">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-2" style="text-align:center; padding:0px 5px;">
                <span class="htt" >3 WAY</span>
            </div>
            <div class="col-md-2 hide-mobi" style="text-align:center; padding:0px 5px;">
                <span class="htt">DOUBLE CHANCE</span>
            </div>
            <div class="col-md-2 hide-mobi" style=" padding:0px 5px;">
                <span class="htt">OVER/UNDER 2.5</span>
            </div>
            <div class="col-md-2 hide-mobi" style=" padding:0px 5px;">
                <span class="htt">BOTH TO SCORE</span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4" style="padding:0px 5px;"></div>
            <div class="col-md-2" style="padding:0px 5px;">
                <table style="width:100%">
                    <tr>
                        <td style="text-align:center;"><span class="htts" style="text-align:center;">HOME</span></td>
                        <td style="text-align:center;"><span class="htts" style="text-align:center;">DRAW</span></td>
                        <td style="text-align:center;"><span class="htts" style="text-align:center;">AWAY</span></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-2 hide-mobi" style="padding:0px 5px;">
                <table style="width:100%">
                    <tr>
                        <td style="text-align:center;"><span class="htts" style="text-align:center;">1ORX</span></td>
                        <td style="text-align:center;"><span class="htts" style="text-align:center;">XOR2</span></td>
                        <td style="text-align:center;"><span class="htts" style="text-align:center;">1OR2</span></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-2 hide-mobi" style="padding:0px 5px;">
            <table style="width:80%">
                    <tr>
                        <td style="text-align:center;"><span class="htts" style="text-align:center;">OVER</span></td>
                        <td style="text-align:center;"><span class="htts" style="text-align:center;">UNDER</span></td>
                    </tr>
                </table>
            </div>
            <div class="col-md-2 hide-mobi" style="padding:0px 5px;">
            <table style="width:80%">
                    <tr>
                        <td style="text-align:center;"><span class="htts" style="text-align:center;">GG</span></td>
                        <td style="text-align:center;"><span class="htts" style="text-align:center;">NG</span></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <div class="odd-sec">
            
            <div class="row">

                <div class="col-md-4" style="padding:0px 5px;">
                    <table style="width:100%">
                        <tr>
                            <td style="padding-left:10px;">
                                <span class="meta-t">26/07/19</span><br>
                                <span class="meta-t">14:30</span><br>
                                <span class="meta-t">ID: 1306</span><br>

                            </td>
                            <td>
                                <span class="meta-tt">Manchester</span><br>
                                <span class="meta-tt"></span><br>
                                <span class="meta-tt">Tottenhum</span><br>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-2 margin-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper">
                        <table class="hide-desktop" style="width:100%">
                        <tr>
                            <td style="text-align:center;"><span class="htts" style="text-align:center;">HOME</span></td>
                            <td style="text-align:center;"><span class="htts" style="text-align:center;">DRAW</span></td>
                            <td style="text-align:center;"><span class="htts" style="text-align:center;">AWAY</span></td>
                        </tr>
                        </table>
                        <table class="" style="width:100%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector">3.60</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; border-left:1px solid #898B8D;">2.23</td>
                            </tr>
                        </table>
                    </div>  
                </div>
                <div class="col-md-2 hide-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper">
                        <table style="width:100%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector">3.60</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; border-left:1px solid #898B8D;">2.23</td>
                            </tr>
                        </table>
                    </div>  
                </div>
                <div class="col-md-2 hide-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper" style="display:flex; justify-content:space-between;">
                        <table style="width:100%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; ">2.23</td>
                            </tr>
                        </table>
                        
                    </div>  
                </div>
                <div class="col-md-2 hide-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper" style="display:flex; justify-content:space-between;">
                        <table style="width:80%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; "> <span>2.23</span> </td>
                            </tr>
                        </table>
                        
                    </div>  
                </div>
            </div>

            
        
        
    
    </div>


    <div class="odd-sec">
            
            <div class="row">

                <div class="col-md-4" style="padding:0px 5px;">
                    <table style="width:100%">
                        <tr>
                            <td style="padding-left:10px;">
                                <span class="meta-t">26/07/19</span><br>
                                <span class="meta-t">14:30</span><br>
                                <span class="meta-t">ID: 1306</span><br>

                            </td>
                            <td>
                                <span class="meta-tt">Manchester</span><br>
                                <span class="meta-tt"></span><br>
                                <span class="meta-tt">Tottenhum</span><br>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-2 margin-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper">
                        <table class="hide-desktop" style="width:100%">
                        <tr>
                            <td style="text-align:center;"><span class="htts" style="text-align:center;">HOME</span></td>
                            <td style="text-align:center;"><span class="htts" style="text-align:center;">DRAW</span></td>
                            <td style="text-align:center;"><span class="htts" style="text-align:center;">AWAY</span></td>
                        </tr>
                        </table>
                        <table class="" style="width:100%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector">3.60</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; border-left:1px solid #898B8D;">2.23</td>
                            </tr>
                        </table>
                    </div>  
                </div>
                <div class="col-md-2 hide-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper">
                        <table style="width:100%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector">3.60</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; border-left:1px solid #898B8D;">2.23</td>
                            </tr>
                        </table>
                    </div>  
                </div>
                <div class="col-md-2 hide-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper" style="display:flex; justify-content:space-between;">
                        <table style="width:100%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; ">2.23</td>
                            </tr>
                        </table>
                        
                    </div>  
                </div>
                <div class="col-md-2 hide-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper" style="display:flex; justify-content:space-between;">
                        <table style="width:80%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; "> <span>2.23</span> </td>
                            </tr>
                        </table>
                        
                    </div>  
                </div>
            </div>

            
        
        
    
    </div>

    <div class="odd-sec">
            
            <div class="row">

                <div class="col-md-4" style="padding:0px 5px;">
                    <table style="width:100%">
                        <tr>
                            <td style="padding-left:10px;">
                                <span class="meta-t">26/07/19</span><br>
                                <span class="meta-t">14:30</span><br>
                                <span class="meta-t">ID: 1306</span><br>

                            </td>
                            <td>
                                <span class="meta-tt">Manchester</span><br>
                                <span class="meta-tt"></span><br>
                                <span class="meta-tt">Tottenhum</span><br>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-2 margin-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper">
                        <table class="hide-desktop" style="width:100%">
                        <tr>
                            <td style="text-align:center;"><span class="htts" style="text-align:center;">HOME</span></td>
                            <td style="text-align:center;"><span class="htts" style="text-align:center;">DRAW</span></td>
                            <td style="text-align:center;"><span class="htts" style="text-align:center;">AWAY</span></td>
                        </tr>
                        </table>
                        <table class="" style="width:100%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector">3.60</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; border-left:1px solid #898B8D;">2.23</td>
                            </tr>
                        </table>
                    </div>  
                </div>
                <div class="col-md-2 hide-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper">
                        <table style="width:100%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector">3.60</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; border-left:1px solid #898B8D;">2.23</td>
                            </tr>
                        </table>
                    </div>  
                </div>
                <div class="col-md-2 hide-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper" style="display:flex; justify-content:space-between;">
                        <table style="width:100%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; ">2.23</td>
                            </tr>
                        </table>
                        
                    </div>  
                </div>
                <div class="col-md-2 hide-mobi" style=" padding:0px 5px;">
                    <div class="odd-selector-wrapper" style="display:flex; justify-content:space-between;">
                        <table style="width:80%">
                            <tr>
                                <td class="odd-selector" style="border-top-left-radius:7px; border-bottom-left-radius:7px; border-right:1px solid #898B8D;">2.91</td>
                                <td class="odd-selector" style="border-top-right-radius:7px; border-bottom-right-radius:7px; "> <span>2.23</span> </td>
                            </tr>
                        </table>
                        
                    </div>  
                </div>
            </div>

            
        
        
    
    </div>
    
</div>




