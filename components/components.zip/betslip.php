<div class="betslip-wrapper">
    <div class="heading-slip" style="padding:10px; background-color:#B21212">
        <span style="color:white;">BETSLIP</span>
    </div>
    <div class="content-sec" style="padding:15px;">
        <div class="spacer-big"></div>

        <img src="svg/paper.svg" alt="">
        <span style="font-size:16px; font-weight:bold;">You have not selected any bet</span>
        <span style="font-size:16px; ">Make your first pick to start playing.</span>
        <div class="spacer-big"></div>
    </div>
</div>
<div class="spacer"></div>

<div class="paybill-wrap">
    <div class="paybill-header"  style="padding:10px; background-color:#000">
    <span style="color:white;">BETSLIP</span>
    </div>
    <div class="paybil">
        <img src="png/bill.png" style="width:100%;" alt="">
    </div>
</div>


<div class="paybill-wrap">
    <div class="paybill-header"  style="padding:10px; background-color:#000">
    <span style="color:white;">CUSTOMER CARE</span>
    </div>
    <div class="paybil">
        <div class="number-sec" style="padding:15px; text-align:center">

        <span style="font-size:16px; font-weight:bold; color:#000;">0708XXXXXX</span><br>
        <hr>
        <span style="font-size:16px; font-weight:bold; color:#000;">0708XXXXXX</span><br>
        </div>
    </div>
    <div class="paybill-header"  style="padding:10px; background-color:#000">
    <span style="color:white; font-style: italic;">email@scorepesa.co.ke</span>
    </div>
</div>