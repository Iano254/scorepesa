<footer style="background-image:url('png/footer.jpg'); color:white; margin-top:30px; background-repeat:no-repeat; background-size:cover; background-position:center;">
<div class="footer-section" style="padding:20px 0px">
    <div class="row">
        <div class="col-md-3"style="padding-right:15px; padding-left:15px;"></div>
        <div class="col-md-3"style="padding-right:15px;">
            <span style="font-weight:bold; font-size:16px">SUPPORT</span>
            <div class="spacer"></div>
            <span class="foot-links">How to Play</span><br>
            <span class="foot-links">terms and conditions</span><br>
            <span class="foot-links">Responsible Gaming</span><br>
            <span class="foot-links">Privacy Policy</span>
        </div>
        <div class="col-md-3" style="padding-right:15px;">
            <span style="font-weight:bold; font-size:16px">LEGAL AND COMPLIANCE</span>
            <div class="spacer"></div>
            <span class="foot-links">This forum is open only to persons over the age of 18 years.</span><br><br>
            <span class="foot-links">Gambling may have adverse effects if not taken in moderation.</span>
            
        </div>
        <div class="col-md-3" style="padding-right:15px;">
            <span style="font-weight:bold; font-size:16px">LICENSE</span>
            <div class="spacer"></div>
            <span class="foot-links">This forum is open only to persons over the age of 18 years.</span><br><br>
            <span class="foot-links">Gambling may have adverse effects if not taken in moderation.</span>
            
        </div>
    </div>
</div>
<div class="copyright-section" style="text-align:center; padding:15px; border-top:1px solid #898B8D">
    <span> &copy <?php echo date('Y')?> Score Pesa Kenya.</span>
</div>
</footer>