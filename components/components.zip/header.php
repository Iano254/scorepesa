<header>
<div class="login-section">
    <div class="logn">
    <button style="border-radius:0px" type="submit" class="btn btn-default login-btn">LOGIN</button>
    </div>
    <div class="sgnp">
    <button style="border-radius:0px" type="submit" class="btn btn-default login-btn">REGISTER</button>
    </div>
    <div class="logo-section">
        <img src="png/logo.png" style="height:75px" alt="">
    </div>
    <div class="form-section">
        <div class="txt-section" >
        <span style="">Welcome to scorepesa</span>
        <span style=" font-weight:bold;">Register Now!</span>
        </div>
        <form class="form-inline" action="/action_page.php">
        <div class="form-group">
            <input style="border-radius:0px" type="phone" class="form-control" id="phone" placeholder="07XXXXXXXX">
        </div>
        <div class="form-group">
            <input style="border-radius:0px" type="password" class="form-control" id="pwd" placeholder="password">
        </div>
        <button style="border-radius:0px" type="submit" class="btn btn-default login-btn">LOGIN</button>
        </form>
        <span style="float:right; margin-top:10px;">Forgot your Password?</span>
    </div>
</div>

<nav class="navbar navbar-default">
  <div class="container-fluid">
  
    <ul class="nav navbar-nav">
      <li class="active"><a href="#"><span class="glyphicon glyphicon-home"></span> Home</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-play-circle"></span> Live Games</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-tasks"></span> Jackpots</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-globe"></span> Live Scores</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-stats"></span> Statistics</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-sound-5-1"></span> Results</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-list-alt"></span> News</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-phone"></span> App</a></li>
      <li><a href="#"><span class="glyphicon glyphicon-question-sign"></span> Help</a></li>
    </ul>
  </div>
</nav>
</header>

